"""Real replay: browser registration, two-admin API approval, worker ACK and browser preview.

Only identities are fixtures; camera/control transitions use authenticated UI/API.
"""

import os
import socket
import subprocess
import sys
import threading
import time
from contextlib import suppress
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
import uvicorn
import yaml
from sqlalchemy import select


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.mark.skipif(os.getenv("RS_MISSION_REAL") != "1", reason="licensed model/media opt-in")
def test_managed_replay_ack_preview_and_revocation(world, tmp_path, monkeypatch, login):
    from roadsentinel.replay import make_server

    from app.config import get_settings
    from app.db import tenant_session
    from app.main import create_app
    from app.models import CameraWorkerStatus
    from app.services import camera_config as cc
    from app.services import ingest_auth
    from app.services.keys import load_keyring

    root = Path(__file__).resolve().parents[2]
    replay = make_server("/tmp/Street_traffic.webm", "127.0.0.1", free_port(), 10)
    disconnect = threading.Event()
    connections = []
    original_get_request = replay.get_request

    def tracked_request():
        connection, address = original_get_request()
        connections.append(connection)
        del connections[:-32]
        return connection, address

    replay.get_request = tracked_request
    replay.verify_request = lambda *_: not disconnect.is_set()
    rt = threading.Thread(target=replay.serve_forever, daemon=True)
    rt.start()
    source = f"http://127.0.0.1:{replay.server_port}/stream.mjpg"
    model = os.environ["RS_YOLOX_MODEL_PATH"]
    digest = __import__("hashlib").sha256(Path(model).read_bytes()).hexdigest()
    cfg = yaml.safe_load((root / "cameras/demo-highway.yaml").read_text())
    config = dict(
        schema_version=1,
        reference_frame=dict(width=1920, height=1080),
        calibration=None,
        min_y=0,
        zones=[
            dict(
                id="scene",
                name="Synthetic scene geometry",
                kind="carriageway",
                direction=[0, 1],
                polygon=[[0, 0], [1919, 0], [1919, 1079], [0, 1079]],
            )
        ],
        rules=["pedestrian_on_road"],
        thresholds=cfg["thresholds"],
        acquisition=dict(
            target_fps=10, reconnect_backoff_s=1, read_timeout_s=3, max_reconnect_attempts=20
        ),
        model=dict(id="override", sha256=digest),
    )
    assert cc.validate(config) == []
    # Control state is created through authenticated APIs, never preapproved DB rows.
    from uuid import UUID

    from app.models import Role
    from tests.conftest import make_user

    monkeypatch.setenv("RS_COOKIE_SECURE", "false")
    get_settings.cache_clear()
    administrator = login(world.a.admin)
    reviewer = login(make_user(world.a.id, Role.tenant_admin, "reviewer@mission.local"))
    from tests.camera_browser import camera_browser

    created = camera_browser(world.a.admin, tmp_path, monkeypatch, "register")
    cid = UUID(created["id"])
    base = f"/api/camera-control/cameras/{cid}"

    def revision():
        response = administrator.get(base)
        assert response.status_code == 200, response.text
        return response.json()["revision"]

    adopted = administrator.post(
        base + "/lifecycle",
        {
            "expected_revision": revision(),
            "reason": "Adopt controlled local replay",
            "to": "onboarding",
        },
    )
    assert adopted.status_code == 200, adopted.text
    registered = administrator.post(
        base + "/source",
        {
            "expected_revision": revision(),
            "reason": "Licensed loopback replay reference",
            "kind": "recorded_replay",
            "url": "replay://mission-fixture",
        },
    )
    assert registered.status_code == 200, registered.text
    grant = administrator.post(
        base + "/grants",
        {
            "granting_party": "Editor / Wikimedia Commons",
            "basis": "licence",
            "basis_reference": "CC BY 3.0 Street traffic.webm",
            "purpose": "Isolated local replay integration test",
            "valid_from": (datetime.now(UTC) - timedelta(days=1)).isoformat(),
            "valid_until": (datetime.now(UTC) + timedelta(days=1)).isoformat(),
            "capture_method": "recorded_replay",
            "max_analysis_fps": 10,
            "max_frame_height": 1080,
            "retention_days": 1,
            "media_scope": "events_only",
        },
    )
    assert grant.status_code == 201, grant.text

    def publish_configuration(value):
        drafted = administrator.post(
            base + "/versions", {"config": value, "reason": "Versioned authorized test geometry"}
        )
        assert drafted.status_code == 201, drafted.text
        vid = drafted.json()["id"]
        assert administrator.post(base + f"/versions/{vid}/validate").status_code == 200
        assert (
            administrator.post(
                base + f"/versions/{vid}/submit",
                {"reason": "Request independent configuration review"},
            ).status_code
            == 200
        )
        assert (
            administrator.post(
                base + f"/versions/{vid}/approve", {"note": "Self approval must be refused"}
            ).status_code
            == 403
        )
        approval = reviewer.post(
            base + f"/versions/{vid}/approve",
            {"note": "Independent reviewer: licensed local replay"},
        )
        assert approval.status_code == 200, approval.text
        active = administrator.post(
            base + "/activate",
            {
                "version_id": vid,
                "expected_revision": revision(),
                "reason": "Activate reviewed configuration",
            },
        )
        assert active.status_code == 200, active.text
        return active.json()

    publish_configuration(config)
    with tenant_session(world.a.id) as db:
        account = ingest_auth.create_account(db, world.a.id, "mission-runtime", camera_ids=[cid])
        key = ingest_auth.issue_key(db, load_keyring(db, world.a.id), account)
        db.commit()
    cfg.update(
        id="mission-replay",
        video=source,
        enabled=True,
        source_replay=True,
        source_fps=10,
        control_source_reference="replay://mission-fixture",
        model=model,
        source_consent=dict(
            granted=True,
            by="Editor / CC BY 3.0",
            date="2026-11-10",
            scope="Local test replay and inference",
            evidence="https://commons.wikimedia.org/wiki/File:Street_traffic.webm",
            licence="CC BY 3.0",
        ),
    )
    profile = tmp_path / "managed.yaml"
    profile.write_text(yaml.safe_dump(cfg))
    port = free_port()
    monkeypatch.setenv("RS_COOKIE_SECURE", "false")
    get_settings.cache_clear()
    server = uvicorn.Server(
        uvicorn.Config(create_app(), host="127.0.0.1", port=port, log_level="error")
    )
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    proc = None
    try:
        deadline = time.monotonic() + 10
        while not server.started and time.monotonic() < deadline:
            time.sleep(0.05)
        log = (tmp_path / "worker.log").open("w+")
        proc = subprocess.Popen(  # noqa: S603 - fixed local fixture executable, no shell
            [
                sys.executable,
                "-m",
                "roadsentinel.pipeline",
                str(profile),
                "--model",
                model,
                "--live",
                "--no-wandb",
            ],
            cwd=root,
            env={
                **os.environ,
                "RS_API_URL": f"http://127.0.0.1:{port}",
                "RS_INGEST_KEY_ID": key.key_id,
                "RS_INGEST_SECRET": key.secret,
            },
            stdout=log,
            stderr=log,
        )
        deadline = time.monotonic() + 35
        ack = False
        operator = login(world.a.operator)
        previews = []
        while time.monotonic() < deadline and proc.poll() is None:
            with tenant_session(world.a.id) as db:
                row = db.scalar(
                    select(CameraWorkerStatus).where(CameraWorkerStatus.camera_id == cid)
                )
                ack = bool(row and row.applied_revision == 1 and row.health == "healthy")
            response = operator.get(f"/api/cameras/{cid}/preview")
            if response.status_code == 200:
                previews.append(__import__("hashlib").sha256(response.content).hexdigest())
            if ack and len(set(previews)) >= 2:
                break
            time.sleep(1)
        log.flush()
        log.seek(0)
        assert ack, log.read()[-2000:]
        assert len(set(previews)) >= 2
        # A competing real process must lose the lease before opening another source.
        opened_before = len(connections)
        duplicate = subprocess.run(  # noqa: S603 - fixed local fixture executable, no shell
            [
                sys.executable,
                "-m",
                "roadsentinel.pipeline",
                str(profile),
                "--model",
                model,
                "--live",
                "--no-wandb",
            ],
            cwd=root,
            env={
                **os.environ,
                "RS_API_URL": f"http://127.0.0.1:{port}",
                "RS_INGEST_KEY_ID": key.key_id,
                "RS_INGEST_SECRET": key.secret,
            },
            stdout=log,
            stderr=log,
            timeout=12,
        )
        assert duplicate.returncode != 0
        assert len(connections) == opened_before
        print("PASS duplicate real worker denied before source open")
        camera_browser(world.a.operator, tmp_path, monkeypatch, "preview", api_port=port)
        updated = dict(config, min_y=10)
        activated = publish_configuration(updated)
        assert activated["version"]["revision"] == 2
        proc.wait(timeout=15)
        assert proc.returncode == 0
        proc = subprocess.Popen(  # noqa: S603 - fixed local fixture executable, no shell
            [
                sys.executable,
                "-m",
                "roadsentinel.pipeline",
                str(profile),
                "--model",
                model,
                "--live",
                "--no-wandb",
            ],
            cwd=root,
            env={
                **os.environ,
                "RS_API_URL": f"http://127.0.0.1:{port}",
                "RS_INGEST_KEY_ID": key.key_id,
                "RS_INGEST_SECRET": key.secret,
            },
            stdout=log,
            stderr=log,
        )
        deadline = time.monotonic() + 25
        applied = False
        while time.monotonic() < deadline and proc.poll() is None:
            with tenant_session(world.a.id) as db:
                row = db.scalar(
                    select(CameraWorkerStatus).where(CameraWorkerStatus.camera_id == cid)
                )
                applied = bool(row and row.applied_revision == 2 and row.health == "healthy")
            if applied:
                break
            time.sleep(0.5)
        assert applied
        print(
            "PASS actual configuration API: independent approval, revision 1 -"
            "> 2, old worker stopped, fresh lease + ACK revision 2"
        )
        # Interrupt only sockets accepted by this test-owned source. Keep control/API up.
        disconnect.set()
        for connection in list(connections):
            with suppress(OSError):
                connection.shutdown(socket.SHUT_RDWR)
        deadline = time.monotonic() + 12
        degraded = False
        while time.monotonic() < deadline and proc.poll() is None:
            with tenant_session(world.a.id) as db:
                row = db.scalar(
                    select(CameraWorkerStatus).where(CameraWorkerStatus.camera_id == cid)
                )
                degraded = bool(row and row.health == "reconnecting")
            if degraded:
                break
            time.sleep(0.5)
        assert degraded
        assert operator.get(f"/api/cameras/{cid}/preview").status_code == 404
        disconnect.clear()
        deadline = time.monotonic() + 25
        recovered = False
        while time.monotonic() < deadline and proc.poll() is None:
            with tenant_session(world.a.id) as db:
                row = db.scalar(
                    select(CameraWorkerStatus).where(CameraWorkerStatus.camera_id == cid)
                )
                healthy = bool(row and row.health == "healthy")
            fresh = operator.get(f"/api/cameras/{cid}/preview")
            if healthy and fresh.status_code == 200:
                recovered = True
                break
            time.sleep(0.5)
        assert recovered
        print(
            "PASS controlled source disconnect: reconnecting, stale preview ex"
            "pired, recovered actual frames"
        )
        disabled = administrator.post(
            base + "/disable",
            {
                "expected_revision": revision(),
                "reason": "Stop capture after successful recovery verification",
            },
        )
        assert disabled.status_code == 200, disabled.text
        proc.wait(timeout=12)
        assert proc.returncode == 0  # supervisor may restart; restart cannot acquire after disable
        requested = administrator.post(
            base + "/enable-request",
            {"expected_revision": revision(), "reason": "Request reviewed local replay recovery"},
        )
        assert requested.status_code == 200, requested.text
        assert (
            administrator.post(
                base + "/enable",
                {"expected_revision": revision(), "reason": "Self enable must be refused"},
            ).status_code
            == 403
        )
        enabled = reviewer.post(
            base + "/enable",
            {"expected_revision": revision(), "reason": "Independent enable after tested disable"},
        )
        assert enabled.status_code == 200, enabled.text
        proc = subprocess.Popen(  # noqa: S603 - fixed local fixture executable, no shell
            [
                sys.executable,
                "-m",
                "roadsentinel.pipeline",
                str(profile),
                "--model",
                model,
                "--live",
                "--no-wandb",
            ],
            cwd=root,
            env={
                **os.environ,
                "RS_API_URL": f"http://127.0.0.1:{port}",
                "RS_INGEST_KEY_ID": key.key_id,
                "RS_INGEST_SECRET": key.secret,
            },
            stdout=log,
            stderr=log,
        )
        deadline = time.monotonic() + 25
        ready = False
        while time.monotonic() < deadline and proc.poll() is None:
            with tenant_session(world.a.id) as db:
                row = db.scalar(
                    select(CameraWorkerStatus).where(CameraWorkerStatus.camera_id == cid)
                )
                ready = bool(row and row.applied_revision == 2 and row.health == "healthy")
            if ready:
                break
            time.sleep(0.5)
        assert ready
        final = administrator.post(
            base + "/pause",
            {"expected_revision": revision(), "reason": "Final test-owned capture shutdown"},
        )
        assert final.status_code == 200, final.text
        proc.wait(timeout=15)
        assert proc.returncode == 0
        print("PASS independent re-enable -> new lease/ACK -> real processing -> final pause")
        print(
            "LOCAL RECORDED REPLAY: actual YOLOX/ByteTrack -> managed lease + "
            "ACK revision 1 -> changing authenticated preview -> stop on disab"
            "le"
        )
    finally:
        if proc and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        replay.shutdown()
        replay.server_close()
        server.should_exit = True
        thread.join(10)
        get_settings.cache_clear()
