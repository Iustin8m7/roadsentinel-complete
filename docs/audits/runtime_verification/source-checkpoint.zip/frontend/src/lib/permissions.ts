import { USE_MOCKS } from './api'
import type { Role } from '@/types'

// Role-based access (README: "acces pe roluri"). Pages and actions check these.
export type Permission =
  | 'dashboard.view'
  | 'alerts.view'
  | 'alerts.decide'
  | 'alerts.dispatch'
  | 'cameras.view'
  | 'video-analysis.view'
  | 'video-analysis.manage'
  | 'rules.view'
  | 'rules.edit'
  | 'archive.search'
  | 'archive.unblur'
  | 'audit.view'
  | 'stats.view'
  | 'patrols.view'
  | 'settings.admin'

const ALL: Permission[] = [
  'dashboard.view',
  'alerts.view',
  'alerts.decide',
  'alerts.dispatch',
  'cameras.view',
  'video-analysis.view',
  'video-analysis.manage',
  'rules.view',
  'rules.edit',
  'archive.search',
  'archive.unblur',
  'audit.view',
  'stats.view',
  'patrols.view',
  'settings.admin',
]

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  admin: ALL,
  operator: [
    'dashboard.view',
    'alerts.view',
    'alerts.decide',
    'alerts.dispatch',
    'cameras.view',
    'video-analysis.view',
    'video-analysis.manage',
    'archive.search',
    'rules.view',
    'patrols.view',
    'stats.view',
  ],
  anchetator: ['dashboard.view', 'alerts.view', 'archive.search', 'archive.unblur', 'audit.view', 'stats.view'],
  patrula: ['dashboard.view', 'alerts.view', 'cameras.view'],
}

export function can(role: Role | undefined, permission: Permission): boolean {
  if (!USE_MOCKS) return !!role && ['dashboard.view', 'alerts.view', 'alerts.decide', 'alerts.dispatch', 'cameras.view', 'video-analysis.view', 'video-analysis.manage', 'archive.search', 'audit.view', 'stats.view'].includes(permission)
  return !!role && ROLE_PERMISSIONS[role].includes(permission)
}

export const hasBackendPermission = (permissions: string[] | undefined, permission: string) =>
  permissions?.includes(permission) ?? false
