import { create } from 'zustand'
import type { SessionUser } from '@/types'
import { api, initCsrf, post, USE_MOCKS, type Me } from '@/lib/api'
import { useAuthStore as mockStore } from './mock-auth'

const sessionUser = (me: Me, role: SessionUser['role'] = 'operator'): SessionUser | null => me.operator || !me.auth_required ? {
  id: me.operator ?? 'local', username: me.operator ?? 'local', fullName: me.operator ?? 'Operator local',
  rank: '', badge: '', unit: '', role,
} : null

/** Real role from the secure backend (/api/auth/me); tenant/system admins map to the UI's admin. */
async function fetchRole(): Promise<SessionUser['role']> {
  try {
    const { role } = await api<{ role: string }>('/api/auth/me')
    return role === 'tenant_admin' || role === 'system_admin' ? 'admin' : 'operator'
  } catch { return 'operator' }
}
export type LoginResult = { ok: true; mfa?: boolean; enrollment?: boolean } | { ok: false; error: string }
interface AuthState {
  user: SessionUser | null; expiresAt: number | null
  login: (username: string, password: string, remember: boolean) => Promise<LoginResult>
  /** Second step. Second factor: TOTP or recovery code, required for every account. */
  verifyMfa: (input: { code: string } | { recovery_code: string }) => Promise<LoginResult>
  startMfaEnrollment: () => Promise<{ ok: true; qr: string; secret: string } | { ok: false; error: string }>
  confirmMfaEnrollment: (code: string) => Promise<{ ok: true; recoveryCodes: string[] } | { ok: false; error: string }>
  logout: () => void; isSessionValid: () => boolean
}
const realStore = create<AuthState>((set, get) => ({
  user: null, expiresAt: null,
  async login(username, password) {
    try {
      await initCsrf()
      const me = await post<Me>('/api/login', { operator: username.trim(), password })
      if (me.mfa_enrollment) return { ok: true, enrollment: true }
      if (me.mfa_required) return { ok: true, mfa: true }
      set({ user: sessionUser(me, await fetchRole()) })
      return { ok: true }
    } catch (error) { return { ok: false, error: (error as Error).message } }
  },
  async verifyMfa(input) {
    try {
      await post('/api/auth/mfa/verify', input)
      const me = await api<Me>('/api/me')
      set({ user: sessionUser(me, await fetchRole()) })
      return { ok: true }
    } catch (error) { return { ok: false, error: (error as Error).message } }
  },
  async startMfaEnrollment() {
    try {
      const started = await post<{ qr_svg_data_uri: string; secret: string }>('/api/auth/mfa/enroll/start')
      return { ok: true, qr: started.qr_svg_data_uri, secret: started.secret }
    } catch (error) { return { ok: false, error: (error as Error).message } }
  },
  async confirmMfaEnrollment(code) {
    try {
      const result = await post<{ recovery_codes: string[] }>('/api/auth/mfa/enroll/confirm', { code })
      const me = await api<Me>('/api/me')
      set({ user: sessionUser(me, await fetchRole()) })
      return { ok: true, recoveryCodes: result.recovery_codes }
    } catch (error) { return { ok: false, error: (error as Error).message } }
  },
  logout() {
    void post('/api/logout').then(() => { set({ user: null }); location.assign('/login') })
      .catch((error: Error) => window.alert(error.message))
  },
  isSessionValid: () => !!get().user,
}))
export const useAuthStore: typeof realStore = USE_MOCKS ? mockStore : realStore
export async function restoreSession() {
  if (USE_MOCKS) return
  await initCsrf()
  const me = await api<Me>('/api/me')
  realStore.setState({ user: sessionUser(me, me.operator ? await fetchRole() : 'operator') })
}
export function actor() {
  const user = useAuthStore.getState().user
  return user ? { username: user.username, role: user.role } : { username: '—', role: 'anonim' as const }
}
