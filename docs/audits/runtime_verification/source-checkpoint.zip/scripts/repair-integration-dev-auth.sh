#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend"
CREDENTIALS="$BACKEND/.integration-test-credentials.json"
ENV_FILE="$BACKEND/.env.integration.local"
EXPECTED_DB="rsint_20261110b"
EXPECTED_HOST="127.0.0.1"
EXPECTED_PORT="55446"

[[ -r "$CREDENTIALS" && -r "$ENV_FILE" ]] || { echo "Integration credentials or environment file missing." >&2; exit 1; }

# Validate the app URL and credentials file before any database command can mutate state.
eval "$(python3 - "$CREDENTIALS" "$ENV_FILE" <<'PY'
import json, shlex, sys
from urllib.parse import urlsplit
cred_path, env_path = sys.argv[1:]
creds = json.load(open(cred_path, encoding='utf-8'))
env = {}
for line in open(env_path, encoding='utf-8'):
    line = line.strip()
    if not line or line.startswith('#') or '=' not in line:
        continue
    key, value = line.split('=', 1)
    env[key] = value.strip().strip('"').strip("'")
url = urlsplit(env['RS_DATABASE_URL'].replace('postgresql+psycopg://', 'postgresql://', 1))
if creds.get('database') != 'rsint_20261110b' or (url.hostname, url.port, url.path.lstrip('/')) != ('127.0.0.1', 55446, 'rsint_20261110b'):
    raise SystemExit('Refusing: credentials and app URL do not identify the approved integration database.')
for key, value in env.items():
    if key.startswith('RS_'):
        print(f'export {key}={shlex.quote(value)}')
print('export RS_SEED_PASSWORD=' + shlex.quote(creds['password']))
PY
)"

if [[ -n "${RS_ADMIN_DATABASE_URL:-}" ]]; then
  ADMIN=(psql "$RS_ADMIN_DATABASE_URL" -X -v ON_ERROR_STOP=1 -At)
else
  command -v sudo >/dev/null && command -v psql >/dev/null || { echo "Set RS_ADMIN_DATABASE_URL or provide sudo and psql for the local PostgreSQL administrator." >&2; exit 1; }
  ADMIN=(sudo -u postgres psql -X -v ON_ERROR_STOP=1 -At -p "$EXPECTED_PORT" -d "$EXPECTED_DB")
fi

# Verify server-side identity and security posture before ALTER ROLE.
IDENTITY="$("${ADMIN[@]}" -c "SELECT current_database() || '|' || current_setting('port') || '|' || coalesce(inet_server_addr()::text,'unix-socket') || '|' || (SELECT rolsuper::text FROM pg_roles WHERE rolname=current_user)")"
[[ "$IDENTITY" == "$EXPECTED_DB|$EXPECTED_PORT|$EXPECTED_HOST|true" || "$IDENTITY" == "$EXPECTED_DB|$EXPECTED_PORT|unix-socket|true" ]] || {
  echo "Refusing: administrator connection is not the expected database/port: $IDENTITY" >&2; exit 1;
}

OWNER="$("${ADMIN[@]}" -c "SELECT pg_get_userbyid(proowner) FROM pg_proc WHERE oid='rs_tenant_id_by_slug(text)'::regprocedure")"
[[ "$OWNER" == "rsint_owner_261110b" ]] || { echo "Refusing: unexpected lookup-function owner '$OWNER'." >&2; exit 1; }
SECURITY="$("${ADMIN[@]}" -c "SELECT (prosecdef AND proconfig @> ARRAY['search_path=public, pg_temp'])::text || '|' || (SELECT (relrowsecurity AND relforcerowsecurity)::text FROM pg_class WHERE oid='tenants'::regclass) FROM pg_proc WHERE oid='rs_tenant_id_by_slug(text)'::regprocedure")"
[[ "$SECURITY" == "true|true" ]] || { echo "Refusing: expected SECURITY DEFINER fixed-search-path function and forced tenant RLS; got $SECURITY" >&2; exit 1; }

"${ADMIN[@]}" -c "ALTER ROLE rsint_owner_261110b BYPASSRLS"
[[ "$("${ADMIN[@]}" -c "SELECT rolbypassrls::text FROM pg_roles WHERE rolname='rsint_owner_261110b'")" == "true" ]] || { echo "Could not enable BYPASSRLS for the migration owner." >&2; exit 1; }

cd "$BACKEND"
if [[ -n "${RS_MIGRATOR_DATABASE_URL:-}" ]]; then
  python -m app.cli migrate
fi

python - <<'PY'
import json
from pathlib import Path

from sqlalchemy import select

from app.db import tenant_session
from app.models import User
from app.services.auth import login_password
from app.services.seed import seed, tenant_id_for_slug
from app.core.security import verify_password

creds = json.loads(Path('.integration-test-credentials.json').read_text())
password = creds['password']
assert tenant_id_for_slug('platform') is not None, 'platform lookup still failed'
before = {}
for email in creds['accounts'].values():
    # Known development accounts are tenant scoped; determine their tenant through the
    # explicitly allow-listed pre-tenant auth lookup, then inspect only in that tenant.
    from sqlalchemy import text
    from app.db import tenant_session
    from app.services.seed import tenant_id_for_slug
    for slug in ('unit-a', 'unit-b', 'platform'):
        tid = tenant_id_for_slug(slug)
        if tid is None:
            continue
        with tenant_session(tid) as db:
            user = db.scalar(select(User).where(User.email == email))
            if user is not None:
                before[email] = verify_password(user.password_hash, password)
                break
seed(password, users_only=True)
after = {}
for email in creds['accounts'].values():
    found = False
    for slug in ('unit-a', 'unit-b', 'platform'):
        tid = tenant_id_for_slug(slug)
        if tid is None:
            continue
        with tenant_session(tid) as db:
            user = db.scalar(select(User).where(User.email == email))
            if user is not None:
                after[email] = (verify_password(user.password_hash, password), user.mfa_enabled)
                found = True
                break
    assert found, f'missing development account after seed: {email}'
    assert after[email][0], f'saved password hash mismatch after seed: {email}'
print('Pre-seed account password hashes:', {email: ('match' if ok else 'mismatch') for email, ok in before.items()})
print('Pre-seed accounts missing:', sorted(set(creds['accounts'].values()) - set(before)))
print('Post-seed account hashes match; MFA state preserved:', {email: state[1] for email, state in after.items()})
email = creds['accounts']['Operator']
with tenant_session() as db:
    result = login_password(db, email, password)
print('Saved-password authentication verified; enrollment required:', result.enrollment_required,
      '(false means the account already has MFA and will receive a TOTP challenge).')
PY

echo "Database repair and development account seeding completed. Restart the backend/frontend processes to load the updated application code."
